package com.app.manikandanr.sampleclients;

class Student {
}
