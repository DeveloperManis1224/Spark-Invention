package com.app.manikandanr.sampleclients;

import org.junit.Test;

import static org.junit.Assert.*;

public class MenuActivityTest {

    @Test
    public void distance() {
    }
}